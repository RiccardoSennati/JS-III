var elenco = [];
var table = document.getElementById('table');

window.addEventListener('DOMContentLoaded', printData);

function printData() {
    fetch('https://jsonplaceholder.typicode.com/users').then((response) => {
        return response.json();
    }).then((data) => {
        elenco = data;
        elenco.map(function (element) {
            table.innerHTML += `<tr> <th>${element.name}</th> <th>${element.username}</th> <td>${element.email}</td> </tr>`
        });
    });
}

