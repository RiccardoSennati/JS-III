class Person {
    constructor(_name, _age) {
        this.name = _name;
        this.age = _age;
    }
    comparison(other) {
        if ((this.age) > (other.age)) {
            return `${this.name} is older then ${other.name}`;
        } else if ((this.age) < (other.age)) {
            return `${this.name} is younger then ${other.name}`;
        } else {
            return `${this.name} is the same age as ${other.name}`;
        }
    }
}
var person1 = new Person('Riccardo', 21);
var person2 = new Person('Lisa', 21);
var person3 = new Person('Alice', 26);

console.log(person3.comparison(person1));
